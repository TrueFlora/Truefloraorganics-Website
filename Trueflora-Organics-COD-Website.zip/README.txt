
Trueflora Organics – COD Store

Customize product data in products.json.
Customize recipient email in cart.js at: const recipientEmail = "your@email.com"

Add or delete products freely.
Future integration for online payment is reserved under <select> option in the checkout form.
